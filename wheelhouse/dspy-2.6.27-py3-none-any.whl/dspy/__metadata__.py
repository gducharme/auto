#replace_package_name_marker
__name__="dspy"
#replace_package_version_marker
__version__="2.6.27"
__description__="DSPy"
__url__="https://github.com/stanfordnlp/dspy"
__author__="Omar Khattab"
__author_email__="okhattab@stanford.edu"