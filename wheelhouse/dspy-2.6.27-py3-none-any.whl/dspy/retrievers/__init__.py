from dspy.retrievers.embeddings import Embeddings

__all__ = ["Embeddings"]
