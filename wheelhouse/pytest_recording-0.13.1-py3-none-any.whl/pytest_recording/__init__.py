import pytest

# Relevant only for VCRpy < 4.4.0
pytest.register_assert_rewrite("vcr.matchers")
